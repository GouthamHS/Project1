----------------------------------------------Readme File----------------------------------------------

Steps

1: Place the esam folder in xampp/htdocs

2: Run Xampp Control panel start Apache and Mysql

3: Open browser and type localhost:portnumber/phpmyadmin

4: Create a database and then click on import.

5: Browse to the database folder, select the database and click GO

6: In connect.inc file for $db enter the database name you have created.

7: for admin login username:Admin, password:admin. No login needed for student and faculty