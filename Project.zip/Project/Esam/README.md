# Exam-Seating-Arrangement
Exam Hall Seating Arrangement System is developed for the college to simplify examination hall allotment and seating arrangement. The project keeps track of each room. 
Back end used: PHP
