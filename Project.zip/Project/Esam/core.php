<?php
require('connect.inc.php');
require('core.inc.php');

if(loggedin())
{// echo "logged in";
  include 'roomdetail.html';
}
else
header('Location: login.html');
?>